This is a proof of concept minesweeper for Tap.

## Node server

In the server directory, you can run:

### `node index.js`

<!-- ## React App

In main directory, you can run:

### `npm start`

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
 -->
